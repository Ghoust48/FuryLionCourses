﻿// Copyright (c) 2012-2019 FuryLion Group. All Rights Reserved.

public enum Difficulty
{
    Easy,
    Medium,
    Hard
}